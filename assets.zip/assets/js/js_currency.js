// str example: 1.000.000
function currencytonum(str){
	if (str == "") return 0;

	// replace all dot to blank
	str = str.replace(/\,/g, "");
	
	// str to int
	return parseFloat(str);
}

// output example: 1,000,000
function numtocurrency(num){
	num = num.toString().replace(/\$|\,/g, '');
	
	if (isNaN(num)) num = "0";
	
	sign = (num == (num = Math.abs(num)));
	num = Math.floor(num * 100 + 0.50000000001);
	cents = num % 100;
	num = Math.floor(num / 100).toString();
	
	if (cents == 0) cents = '';
	else if (cents < 10) cents = ".0" + cents;
	else cents = '.' + cents;
	
	for (var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++)
		num = num.substring(0, num.length - (4 * i + 3)) + ',' + num.substring(num.length - (4 * i + 3));
	
	return (((sign) ? '' : '-') + num + cents );
}